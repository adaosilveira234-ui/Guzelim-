const $=s=>document.querySelector(s);
const screens=[...document.querySelectorAll('.screen')];
function show(id){screens.forEach(x=>x.classList.toggle('active',x.id===id));}
const bank=[
{t:"culture",q:"Qual é o maior oceano da Terra?",a:["Atlântico","Índico","Pacífico","Ártico"],c:2},
{t:"science",q:"Qual é o símbolo químico da água?",a:["CO₂","H₂O","O₂","NaCl"],c:1},
{t:"football",q:"Quantos jogadores de cada equipa iniciam uma partida de futebol?",a:["9","10","11","12"],c:2},
{t:"geo",q:"Qual é a capital de Angola?",a:["Benguela","Huambo","Luanda","Lubango"],c:2},
{t:"anime",q:"Em Naruto, qual é o nome da aldeia de Naruto?",a:["Aldeia da Areia","Aldeia da Folha","Aldeia da Névoa","Aldeia da Pedra"],c:1},
{t:"music",q:"Qual destes é um instrumento de cordas?",a:["Flauta","Tambor","Violino","Trompete"],c:2},
{t:"science",q:"Qual planeta é conhecido como planeta vermelho?",a:["Vénus","Marte","Júpiter","Saturno"],c:1},
{t:"football",q:"Que cartão significa expulsão no futebol?",a:["Azul","Verde","Amarelo","Vermelho"],c:3},
{t:"geo",q:"Em que continente fica o Egipto?",a:["África","Europa","Ásia","América"],c:0},
{t:"culture",q:"Quantos lados tem um hexágono?",a:["5","6","7","8"],c:1},
{t:"anime",q:"Qual destes é um género de anime?",a:["Shōnen","Soneto","Samba","Ópera"],c:0},
{t:"music",q:"Qual é a família do piano?",a:["Percussão","Sopro","Cordas percutidas","Metais"],c:2},
{t:"science",q:"Que órgão bombeia o sangue?",a:["Pulmão","Cérebro","Coração","Fígado"],c:2},
{t:"geo",q:"Em que ano Angola tornou-se independente?",a:["1961","1975","1980","1992"],c:1},
{t:"football",q:"Como se chama o jogador que protege a baliza?",a:["Avançado","Guarda-redes","Médio","Árbitro"],c:1},
{t:"culture",q:"Qual é o resultado de 8 × 7?",a:["54","56","64","48"],c:1}
];
const labels={culture:"CULTURA GERAL",science:"CIÊNCIA",football:"FUTEBOL",geo:"GEOGRAFIA E HISTÓRIA",anime:"ANIME",music:"MÚSICA"};
let room="quiz",theme="mixed",questions=[],idx=0,turn=0,scores=[0,0],seconds=10,timer=null,locked=false,sound=true;
let totals=JSON.parse(localStorage.getItem("guzelimTotals")||"[0,0]");
function updateTotals(){localStorage.setItem("guzelimTotals",JSON.stringify(totals));$("#menuScore").textContent=`Adão ${totals[0]} · Güzelim ${totals[1]}`;}
function beep(freq=600,dur=.12){if(!sound)return;try{let c=new(window.AudioContext||window.webkitAudioContext)(),o=c.createOscillator(),g=c.createGain();o.connect(g);g.connect(c.destination);o.frequency.value=freq;g.gain.value=.045;o.start();g.gain.exponentialRampToValueAtTime(.001,c.currentTime+dur);o.stop(c.currentTime+dur)}catch(e){}}
function shuffle(a){return [...a].sort(()=>Math.random()-.5)}
function start(){scores=[0,0];turn=0;idx=0;let pool=room==="themes"&&theme!=="mixed"?bank.filter(x=>x.t===theme):bank;questions=shuffle(pool).slice(0,Math.min(8,pool.length));show("game");renderQuestion();}
function renderQuestion(){
 clearInterval(timer);locked=false;seconds=10;$("#roundLabel").textContent=`PERGUNTA ${idx+1} / ${questions.length}`;$("#currentPlayer").textContent=turn===0?"Adão":"Güzelim";$("#timerText").textContent=seconds;$("#timerBar").style.width="100%";$("#category").textContent=labels[questions[idx].t];$("#question").textContent=questions[idx].q;$("#feedback").textContent="";$("#nextBtn").classList.add("hidden");$("#scoreA").textContent=`Adão: ${scores[0]}`;$("#scoreG").textContent=`Güzelim: ${scores[1]}`;
 $("#answers").innerHTML="";questions[idx].a.forEach((v,i)=>{let b=document.createElement("button");b.className="answer";b.textContent=`${String.fromCharCode(65+i)}. ${v}`;b.onclick=()=>answer(i);$("#answers").append(b)});
 timer=setInterval(()=>{seconds--;$("#timerText").textContent=seconds;$("#timerBar").style.width=(seconds/10*100)+"%";if(seconds<=0)answer(-1)},1000);
}
function answer(choice){if(locked)return;locked=true;clearInterval(timer);let q=questions[idx],buttons=[...document.querySelectorAll(".answer")];buttons.forEach((b,i)=>{b.disabled=true;if(i===q.c)b.classList.add("correct");if(i===choice&&choice!==q.c)b.classList.add("wrong")});if(choice===q.c){scores[turn]++;$("#feedback").textContent="Resposta certa! +1 ponto";beep(880,.18)}else{$("#feedback").textContent=choice===-1?"O tempo terminou!":"Resposta errada!";beep(190,.2)}$("#scoreA").textContent=`Adão: ${scores[0]}`;$("#scoreG").textContent=`Güzelim: ${scores[1]}`;$("#nextBtn").classList.remove("hidden");}
function next(){idx++;turn=1-turn;if(idx>=questions.length)finish();else renderQuestion();}
function finish(){clearInterval(timer);totals[0]+=scores[0];totals[1]+=scores[1];updateTotals();$("#finalA").textContent=scores[0];$("#finalG").textContent=scores[1];let msg=scores[0]===scores[1]?"Empate! Os dois estiveram à altura.":scores[0]>scores[1]?"Adão venceu esta partida!":"Güzelim venceu esta partida!";$("#resultTitle").textContent=scores[0]===scores[1]?"Partida empatada!":"Temos um vencedor!";$("#resultText").textContent=msg;show("result");}
$("#startBtn").onclick=()=>{show("menu");updateTotals()};
document.querySelectorAll("[data-home]").forEach(b=>b.onclick=()=>show("home"));
document.querySelectorAll("[data-menu]").forEach(b=>b.onclick=()=>{clearInterval(timer);show("menu")});
document.querySelectorAll("[data-room]").forEach(b=>b.onclick=()=>{room=b.dataset.room;$("#setupTitle").textContent=room==="quiz"?"Perguntas & Respostas":"Temas diferentes";$("#themePicker").classList.toggle("hidden",room==="quiz");show("setup")});
document.querySelectorAll(".theme").forEach(b=>b.onclick=()=>{document.querySelectorAll(".theme").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");theme=b.dataset.theme});
$("#playBtn").onclick=start;$("#nextBtn").onclick=next;$("#againBtn").onclick=()=>{show("setup")};
$("#resetScores").onclick=()=>{totals=[0,0];updateTotals();$("#toast").textContent="Pontuação reiniciada";$("#toast").classList.add("show");setTimeout(()=>$("#toast").classList.remove("show"),1600)};
$("#soundBtn").onclick=()=>{sound=!sound;$("#soundBtn").textContent=sound?"🔊":"🔇";if(sound)beep()};
updateTotals();
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));